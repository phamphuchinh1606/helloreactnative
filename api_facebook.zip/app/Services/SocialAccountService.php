<?php

namespace App\Services;

use App\Common\Utils;
use Laravel\Socialite\Contracts\User as ProviderUser;
use App\Models\SocialAccount;
use App\User;

class SocialAccountService
{
    public static function createOrGetUser(ProviderUser $providerUser, $social)
    {

        if(Utils::$API_NAME_INSTAGRAM == $social){
            $user = SocialAccountService::createUserFromInstagram($providerUser);
        }else if(Utils::$API_NAME_FACEBOOK == $social){
            $user = SocialAccountService::creaetUserFacebook($providerUser);
        }
        return $user;
    }

    private static function createUserFromInstagram($userInfo){
        $social = Utils::$API_NAME_INSTAGRAM;

        $userInstagram = $userInfo->accessTokenResponseBody['user'];
        $id = $userInstagram['id'];
        $token = $userInfo->accessTokenResponseBody['access_token'];
        $account = SocialAccount::whereProvider($social)
            ->whereProviderUserId($id)
            ->first();
        if ($account) {
            return $account->user;
        } else {
            $email = $userInfo->getEmail() ?? $userInfo->getNickname();
            $account = new SocialAccount([
                'provider_user_id' => $id,
                'provider' => $social
            ]);
            $account->token = $token;
            if(isset($userInfo->nickname)){
                $account->nickname = $userInfo->nickname;
            }
            if(isset($userInfo->name)){
                $account->name = $userInfo->name;
            }

            $user = User::whereEmail($email)->first();

            if (!$user) {

                $user = User::create([
                    'email' => $userInstagram['username'].$id,
                    'name' => $userInstagram['username'],
                    'password' => $userInstagram['username'],
                    'avatar' => $userInstagram['profile_picture'],
                    'token_api' => $token,
                ]);
            }

            $account->user()->associate($user);
            $account->save();

            return $user;
        }
    }

    private static function creaetUserFacebook($userInfo){
        $social = Utils::$API_NAME_INSTAGRAM;
        $account = SocialAccount::whereProvider($social)
            ->whereProviderUserId($userInfo->getId())
            ->first();
        if ($account) {
            return $account->user;
        } else {
            $email = $userInfo->getEmail() ?? $userInfo->getNickname();
            $account = new SocialAccount([
                'provider_user_id' => $userInfo->getId(),
                'provider' => $social
            ]);
            if(isset($userInfo->token)){
                $account->token = $userInfo->token;
            }
            if(isset($providerUser->nickname)){
                $account->nickname = $userInfo->nickname;
            }
            if(isset($providerUser->name)){
                $account->name = $userInfo->name;
            }

            $user = User::whereEmail($email)->first();

            if (!$user) {

                $user = User::create([
                    'email' => $email,
                    'name' => $userInfo->getName(),
                    'password' => $userInfo->getName(),
                    'avatar' => $userInfo->avatar,
                    'token_api' => $userInfo->token,
                ]);
            }

            $account->user()->associate($user);
            $account->save();

            return $user;
        }
    }
}