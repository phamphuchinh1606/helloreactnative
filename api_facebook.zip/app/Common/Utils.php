<?php
namespace App\Common;

class Utils
{
    public static $API_NAME_TWITTER = 'twitter';
    public static $API_NAME_FACEBOOK = 'facebook';
    public static $API_NAME_INSTAGRAM = 'instagram';
}